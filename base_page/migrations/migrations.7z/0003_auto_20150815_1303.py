# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base_page', '0002_grouplist'),
    ]

    operations = [
        migrations.AlterField(
            model_name='grouplist',
            name='register',
            field=models.NullBooleanField(default=False),
        ),
    ]
